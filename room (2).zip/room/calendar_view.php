<table class="table table-bordered">
    <tr>
        <th width="20%">ผู้บันทึกข้อมูล</th>
        <td id="fullname"></td>
    </tr>
    <tr>
        <th>หน่วยงาน</th>
        <td id="department"></td>
    </tr>
    <tr>
        <th >เรื่อง</th>
        <td id="title"></td>
    </tr>
    <tr>
        <th>เริ่มใช้ห้อง</th>
        <td id="booking_start"></td>
    </tr>
    <tr>
        <th>สิ้นสุดการใช้ห้อง</th>
        <td id="booking_end"></td>
    </tr>
    <tr>
        <th>รายละเอียด</th>
        <td id="description"></td>
    </tr>
    <tr>
        <th>จำนวนผู้เข้าประชุม</th>
        <td id="person_use"></td>
    </tr>
    <tr>
        <th>ชื่อห้องประชุม</th>
        <td  id="room_name"></td>
    </tr>
    <tr>
        <th>ภาพห้องประชุม</th>
        <td  id="room_image"></td>
    </tr>
    <!--<tr>
        <th>อุปกรณ์เพิ่มเติม</th>
        <td id="equipment"></td>
    </tr>-->
    <tr>
        <th>สถานะ</th>
        <td id="status"></td>
    </tr>
</table>