<footer class="main-footer">
	<div class="pull-right hidden-xs">
	  <b>Meeting Calendar V 1.0.1</b>
	</div>
	<br>
</footer>